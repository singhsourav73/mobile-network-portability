var HelloContract = artifacts.require("HelloWorld");
module.exports = function() {
    HelloContract.deployed().then(function(instance) {
        hello = instance;
        return hello.sayHello();
    }).then(function(result) {
        console.log(result);
    }).catch(function(e) {
        
    });
}